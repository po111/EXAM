export const JWT_SECRET = '99e13972210cfa6ebacb72fce1700814';
export const AUTH_COOKIE_NAME = 'auth';